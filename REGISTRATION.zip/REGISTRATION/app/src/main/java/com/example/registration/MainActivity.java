package com.example.registration;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editTextName, editTextFatherName;
    private AutoCompleteTextView autoCompletePlaceOfBirth;
    private RadioGroup radioGroupGender;
    private Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        editTextName = findViewById(R.id.editTextName);
        editTextFatherName = findViewById(R.id.editTextFatherName);
        autoCompletePlaceOfBirth = findViewById(R.id.autoCompletePlaceOfBirth);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        // Set up AutoCompleteTextView
        String[] places = new String[]{"BLR", "CHENNAI", "DELHI"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, places);
        autoCompletePlaceOfBirth.setAdapter(adapter);

        // Set up the Submit button
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitForm();
            }
        });
    }

    private void submitForm() {
        String name = editTextName.getText().toString();
        String fatherName = editTextFatherName.getText().toString();
        String placeOfBirth = autoCompletePlaceOfBirth.getText().toString();
        int selectedGenderId = radioGroupGender.getCheckedRadioButtonId();
        RadioButton selectedGender = findViewById(selectedGenderId);
        String gender = selectedGender != null ? selectedGender.getText().toString() : "";

        // For now, just show a Toast message with the entered data
        String message = "Name: " + name + "\nFather's Name: " + fatherName +
                "\nPlace of Birth: " + placeOfBirth + "\nGender: " + gender;
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}

