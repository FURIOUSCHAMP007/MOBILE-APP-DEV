
package com.example.budgettracker;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;

public class SummaryActivity extends AppCompatActivity {

    private TextView summaryTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        summaryTextView = findViewById(R.id.summaryTextView);

        // Get the expenses list from the intent
        ArrayList<HashMap<String, String>> expensesList = (ArrayList<HashMap<String, String>>) getIntent().getSerializableExtra("expensesList");

        // Calculate total expenses for each category
        HashMap<String, Double> categoryTotals = new HashMap<>();
        for (HashMap<String, String> expense : expensesList) {
            String category = expense.get("category");
            double amount = Double.parseDouble(expense.get("amount"));
            if (categoryTotals.containsKey(category)) {
                categoryTotals.put(category, categoryTotals.get(category) + amount);
            } else {
                categoryTotals.put(category, amount);
            }
        }

        // Display the summary
        StringBuilder summaryText = new StringBuilder();
        for (String category : categoryTotals.keySet()) {
            summaryText.append("Category: ").append(category).append("\n")
                    .append("Total: ₹").append(categoryTotals.get(category)).append("\n\n");
        }
        summaryTextView.setText(summaryText.toString());
    }
}
