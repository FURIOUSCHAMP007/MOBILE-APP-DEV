package com.example.budgettracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private EditText itemNameInput, amountInput;
    private Spinner categorySpinner;
    private DatePicker datePicker;
    private Button submitButton;
    private ArrayList<HashMap<String, String>> expensesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        itemNameInput = findViewById(R.id.editTextItemName);
        amountInput = findViewById(R.id.editTextAmount);
        categorySpinner = findViewById(R.id.categorySpinner);
        datePicker = findViewById(R.id.datePicker);
        submitButton = findViewById(R.id.btnSubmitExpense);
        expensesList = new ArrayList<>();

        // Spinner setup (Example categories)
        String[] categories = {"Food", "Transport", "Entertainment", "Other"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categories);
        categorySpinner.setAdapter(adapter);

        // Button click listener
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get values from input fields
                String itemName = itemNameInput.getText().toString();
                String category = categorySpinner.getSelectedItem().toString();
                double amount = Double.parseDouble(amountInput.getText().toString());
                String date = datePicker.getDayOfMonth() + "/" + (datePicker.getMonth() + 1) + "/" + datePicker.getYear();

                // Store the expense in a HashMap
                HashMap<String, String> expense = new HashMap<>();
                expense.put("itemName", itemName);
                expense.put("category", category);
                expense.put("amount", String.valueOf(amount));
                expense.put("date", date);

                // Add the expense to the list
                expensesList.add(expense);

                // Pass the expenses list to the next activity
                Intent intent = new Intent(MainActivity.this, SummaryActivity.class);
                intent.putExtra("expensesList", expensesList);
                startActivity(intent);
            }
        });
    }
}
