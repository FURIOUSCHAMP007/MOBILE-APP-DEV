package com.example.electives;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText name, rollno;
    Spinner elec;
    TextView res;
    String selectedCourse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializing UI elements
        name = findViewById(R.id.nameBox);
        rollno = findViewById(R.id.rollnoBox);
        elec = findViewById(R.id.electivesBox);
        res = findViewById(R.id.result);

        // Setting up the Spinner (Dropdown)
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.courses, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        elec.setAdapter(adapter);

        // Spinner item selection event handler
        elec.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedCourse = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // No action needed here
            }
        });
    }

    // Function to display selected details
    public void displayDetails(View v) {
        String studentName = name.getText().toString();
        String rollNumber = rollno.getText().toString();
        res.setText("Name: " + studentName + "\nRoll No: " + rollNumber + "\nSelected Course: " + selectedCourse);
    }

    // Function to reset the form details
    public void resetDetails(View v) {
        name.setText("");
        rollno.setText("");
        res.setText("");
        elec.setSelection(0); // Resetting the Spinner to the first ite
    } }