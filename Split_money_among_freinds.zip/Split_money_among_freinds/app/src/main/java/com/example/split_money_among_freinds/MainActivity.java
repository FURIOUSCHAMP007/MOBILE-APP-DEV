package com.example.split_money_among_freinds;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button b1;
    EditText No_Of_freinds, Expense;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.button);
        Expense = findViewById(R.id.editTextText);
        No_Of_freinds = findViewById(R.id.editTextText2);

        b1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                int expense = Integer.parseInt(Expense.getText().toString());
                int noofFreinds = Integer.parseInt(No_Of_freinds.getText().toString());
                int equalMoney = expense/noofFreinds;
                Intent i = new Intent(getApplicationContext(), MainActivity2.class);
                i.putExtra("division",equalMoney);
                startActivity(i);

            }
        });

    }
}