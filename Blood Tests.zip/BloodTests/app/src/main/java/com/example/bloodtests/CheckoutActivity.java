package com.example.bloodtests;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class CheckoutActivity extends AppCompatActivity {

    private TextView tvReceipt;
    private Button btnCheckout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        tvReceipt = findViewById(R.id.tvReceipt);
        btnCheckout = findViewById(R.id.btnCheckout);

        Bundle extras = getIntent().getExtras();
        String name = extras.getString("name");
        String phoneNumber = extras.getString("phoneNumber");
        String email = extras.getString("email");
        String address = extras.getString("address");
        String testType = extras.getString("testType");

        String receiptDetails = "Name: " + name +
                "\nPhone Number: " + phoneNumber +
                "\nEmail ID: " + email +
                "\nAddress: " + address +
                "\nTest Type: " + testType;

        tvReceipt.setText(receiptDetails);

        btnCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int amount = calculateAmount(testType);
                tvReceipt.append("\nTotal Amount: Rs. " + amount);
            }
        });
    }

    private int calculateAmount(String testType) {
        switch (testType) {
            case "Blood Sugar":
                return 500;
            case "Complete Blood Count":
                return 700;
            case "Liver Function Test":
                return 1000;
            case "Thyroid Test":
                return 800;
            default:
                return 0;
        }
    }
}
