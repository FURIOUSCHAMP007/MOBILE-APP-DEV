package com.example.movieticketbookingsp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText count;
    ListView list; // Changed Spinner to ListView
    Button sub;
    String[] movies = {"Jawan", "Leo", "Tiger 3", "Ghost"};
    int selectedPos = -1; // Default to -1 for no selection
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        count = findViewById(R.id.ticketsctBox);
        list = findViewById(R.id.movieslist);
        sub = findViewById(R.id.submitBtn);

        // Set up the ListView with an ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_single_choice, movies);
        list.setAdapter(adapter);
        list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        // Handle ListView item click events
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedPos = position; // Track the selected position
            }
        });

        // Set up the Submit button click listener
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedPos == -1) {
                    Toast.makeText(MainActivity.this, "Please select a movie", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (count.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter the number of tickets", Toast.LENGTH_SHORT).show();
                    return;
                }

                sharedPreferences = getSharedPreferences("MyPreferences", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("MovieName", selectedPos);
                editor.putInt("TicketsCount", Integer.parseInt(count.getText().toString()));
                editor.apply();

                Toast.makeText(MainActivity.this, "Saved Successfully", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Retrieve data from SharedPreferences
        SharedPreferences sh = getSharedPreferences("MyPreferences", MODE_PRIVATE);
        int spos = sh.getInt("MovieName", -1); // Default to -1 for no selection
        int ct = sh.getInt("TicketsCount", 0);

        // Restore selection in ListView
        if (spos != -1) {
            list.setItemChecked(spos, true);
            selectedPos = spos;
        }

        // Restore ticket count
        count.setText(ct == 0 ? "" : String.valueOf(ct));
    }
}
