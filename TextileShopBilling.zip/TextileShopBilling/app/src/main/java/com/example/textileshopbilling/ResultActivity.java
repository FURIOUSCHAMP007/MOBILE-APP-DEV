package com.example.textileshopbilling;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {
    EditText editSearchCustomer;
    Button buttonSearchCustomer;
    TextView textResult;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        editSearchCustomer = findViewById(R.id.editSearchCustomer);
        buttonSearchCustomer = findViewById(R.id.buttonSearchCustomer);
        textResult = findViewById(R.id.textResult);

        db = openOrCreateDatabase("TextileShopDB", MODE_PRIVATE, null);

        buttonSearchCustomer.setOnClickListener(view -> {
            String customerName = editSearchCustomer.getText().toString();
            if (customerName.isEmpty()) {
                Toast.makeText(this, "Enter a customer name", Toast.LENGTH_SHORT).show();
            } else {
                fetchCustomerDetails(customerName);
            }
        });
    }

    private void fetchCustomerDetails(String customerName) {
        Cursor cursor = db.rawQuery("SELECT * FROM Customers WHERE name=?", new String[]{customerName});
        if (cursor.moveToFirst()) {
            StringBuilder result = new StringBuilder();
            do {
                result.append("Name: ").append(cursor.getString(1))
                        .append("\nMobile: ").append(cursor.getString(2))
                        .append("\nGender: ").append(cursor.getString(3))
                        .append("\nItem: ").append(cursor.getString(4))
                        .append("\nQuantity: ").append(cursor.getInt(5))
                        .append("\nDateTime: ").append(cursor.getString(6))
                        .append("\n\n");
            } while (cursor.moveToNext());
            textResult.setText(result.toString());
        } else {
            textResult.setText("No details found for the customer.");
        }
    }
}
