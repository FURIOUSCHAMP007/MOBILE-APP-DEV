package com.example.textileshopbilling;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    EditText editCustomerName, editMobileNumber, editDateTime;
    RadioGroup radioGroupGender;
    AutoCompleteTextView autoCompleteItem;
    Spinner spinnerItems;
    Button buttonSave, buttonViewResults;
    SQLiteDatabase db;
    Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        editCustomerName = findViewById(R.id.editCustomerName);
        editMobileNumber = findViewById(R.id.editMobileNumber);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        autoCompleteItem = findViewById(R.id.autoCompleteItem);
        spinnerItems = findViewById(R.id.spinnerItems);
        editDateTime = findViewById(R.id.editDateTime);
        buttonSave = findViewById(R.id.buttonSave);
        buttonViewResults = findViewById(R.id.buttonViewResults);

        // Initialize Calendar
        calendar = Calendar.getInstance();

        // Set Date and Time Picker
        editDateTime.setOnClickListener(v -> showDateTimePicker());

        // Initialize Database
        db = openOrCreateDatabase("TextileShopDB", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, mobile TEXT, gender TEXT, item TEXT, quantity INTEGER, dateTime TEXT)");

        // Populate Spinner
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this, R.array.item_quantities, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerItems.setAdapter(spinnerAdapter);

        // AutoComplete Item Suggestions
        String[] items = {"Shirt", "Pants", "Saree", "Blouse", "Towel"};
        ArrayAdapter<String> autoCompleteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        autoCompleteItem.setAdapter(autoCompleteAdapter);

        // Save Button
        buttonSave.setOnClickListener(view -> saveCustomerDetails());

        // View Results Button
        buttonViewResults.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ResultActivity.class);
            startActivity(intent);
        });
    }

    private void showDateTimePicker() {
        // Date Picker
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

            // Time Picker
            TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view1, hourOfDay, minute) -> {
                calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                calendar.set(Calendar.MINUTE, minute);

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                editDateTime.setText(sdf.format(calendar.getTime()));
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true);
            timePickerDialog.show();
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    private void saveCustomerDetails() {
        String name = editCustomerName.getText().toString();
        String mobile = editMobileNumber.getText().toString();
        int selectedGenderId = radioGroupGender.getCheckedRadioButtonId();
        String gender;
        if (selectedGenderId == -1) {
            Toast.makeText(this, "Please select a gender", Toast.LENGTH_SHORT).show();
            return;
        } else {
            gender = selectedGenderId == R.id.radioMale ? "Male" : "Female";
        }
        String item = autoCompleteItem.getText().toString();
        int quantity = Integer.parseInt(spinnerItems.getSelectedItem().toString());
        String dateTime = editDateTime.getText().toString();

        if (name.isEmpty() || mobile.isEmpty() || item.isEmpty() || dateTime.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
        } else {
            db.execSQL("INSERT INTO Customers(name, mobile, gender, item, quantity, dateTime) VALUES(?,?,?,?,?,?)",
                    new Object[]{name, mobile, gender, item, quantity, dateTime});
            Toast.makeText(this, "Details Saved", Toast.LENGTH_SHORT).show();
        }
    }
}