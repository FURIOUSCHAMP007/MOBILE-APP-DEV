package com.example.flightmodeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView flightModeText;
    private FlightModeReceiver flightModeReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        flightModeText = findViewById(R.id.flightModeText);

        // Initialize the receiver
        flightModeReceiver = new FlightModeReceiver(flightModeText);

        // Register the receiver
        IntentFilter filter = new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        registerReceiver(flightModeReceiver, filter);
    }

    // Method triggered by button click
    public void checkFlightModeStatus(View view) {
        boolean isFlightModeOn = Settings.Global.getInt(
                getContentResolver(),
                Settings.Global.AIRPLANE_MODE_ON, 0
        ) != 0;

        if (isFlightModeOn) {
            flightModeText.setText("Flight Mode Status: ON");
        } else {
            flightModeText.setText("Flight Mode Status: OFF");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the receiver to avoid memory leaks
        unregisterReceiver(flightModeReceiver);
    }
}
