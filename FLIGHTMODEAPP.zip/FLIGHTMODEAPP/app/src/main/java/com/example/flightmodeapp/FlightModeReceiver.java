package com.example.flightmodeapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.TextView;

public class FlightModeReceiver extends BroadcastReceiver {
    private final TextView flightModeText;

    public FlightModeReceiver(TextView flightModeText) {
        this.flightModeText = flightModeText;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_AIRPLANE_MODE_CHANGED.equals(intent.getAction())) {
            boolean isFlightModeOn = intent.getBooleanExtra("state", false);
            if (isFlightModeOn) {
                flightModeText.setText("Flight Mode Status: ON");
            } else {
                flightModeText.setText("Flight Mode Status: OFF");
            }
        }
    }
}
