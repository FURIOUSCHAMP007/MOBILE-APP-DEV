package com.example.bmicalc;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Declaring the UI components
    EditText wtval, htval;
    Button btn;
    TextView res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initializing the UI components
        wtval = findViewById(R.id.wtBox);
        htval = findViewById(R.id.htBox);
        btn = findViewById(R.id.calcBtn);
        res = findViewById(R.id.result);

        // Setting click listener on the calculate button
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Input validation
                if (wtval.getText().toString().isEmpty() || htval.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter valid weight and height", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    // Parsing input values
                    Float wt = Float.parseFloat(wtval.getText().toString());
                    Float ht_m = Float.parseFloat(htval.getText().toString()) / 100;

                    // Handling division by zero scenario
                    if (ht_m == 0) {
                        Toast.makeText(MainActivity.this, "Height cannot be zero", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Calculating BMI
                    Float bmi = wt / (ht_m * ht_m);

                    // Formatting BMI result to two decimal places
                    String bmiResult = String.format("%.2f", bmi);

                    // Displaying BMI category
                    if (bmi < 18.5) {
                        res.setText("The BMI is: " + bmiResult + "\n Underweight");
                    } else if (bmi >= 18.5 && bmi < 24.9) {
                        res.setText("The BMI is: " + bmiResult + "\n Healthy");
                    } else if (bmi >= 24.9 && bmi < 30) {
                        res.setText("The BMI is: " + bmiResult + "\n Overweight");
                    } else {
                        res.setText("The BMI is: " + bmiResult + "\n Suffering from obesity");
                    }
                } catch (NumberFormatException e) {
                    // Handle invalid numeric input
                    Toast.makeText(MainActivity.this, "Please enter valid numeric values", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
