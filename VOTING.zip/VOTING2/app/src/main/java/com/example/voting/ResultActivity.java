package com.example.voting;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultActivity extends AppCompatActivity {
    TextView res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // Initialize the TextView
        res = findViewById(R.id.result);

        // Get the Intent that started this activity and extract the data
        Intent intt = getIntent();
        String r_name = intt.getStringExtra("NAME");
        String r_aadhar = intt.getStringExtra("AADHAR");
        int age = intt.getIntExtra("AGE", 0);

        // Check eligibility based on the age
        if (age >= 18) {
            res.setText("Name: " + r_name + "\nAadhar Number: " + r_aadhar + "\nYou are eligible to vote");
        } else {
            res.setText("Name: " + r_name + "\nAadhar Number: " + r_aadhar + "\nYou are not eligible to vote");
        }
    }
}