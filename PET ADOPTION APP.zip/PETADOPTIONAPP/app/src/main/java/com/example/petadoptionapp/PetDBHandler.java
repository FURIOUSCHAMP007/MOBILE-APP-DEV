package com.example.petadoptionapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PetDBHandler extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "PetAdoptionDB";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_PETS = "Pets";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_CATEGORY = "category";
    private static final String COLUMN_OWNER_MAIL = "ownerMail";
    private static final String COLUMN_STATUS = "status";
    private static final String COLUMN_AGE = "age";

    public PetDBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_PETS_TABLE = "CREATE TABLE " + TABLE_PETS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_CATEGORY + " TEXT, " +
                COLUMN_OWNER_MAIL + " TEXT, " +
                COLUMN_STATUS + " TEXT, " +
                COLUMN_AGE + " INTEGER" + ")";
        db.execSQL(CREATE_PETS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PETS);
        onCreate(db);
    }

    // Insert Data
    public void addPet(String category, String ownerMail, String status, int age) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY, category);
        values.put(COLUMN_OWNER_MAIL, ownerMail);
        values.put(COLUMN_STATUS, status);
        values.put(COLUMN_AGE, age);
        db.insert(TABLE_PETS, null, values);
        db.close();
    }

    // Fetch available pets
    public Cursor getAvailablePets() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_PETS + " WHERE " + COLUMN_STATUS + "='Available'", null);
    }

    // Fetch pets aged 1 year
    public Cursor getOneYearOldPets() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_PETS + " WHERE " + COLUMN_AGE + "=1", null);
    }

    // Fetch pets in Birds category
    public Cursor getBirds() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_PETS + " WHERE " + COLUMN_CATEGORY + "='Birds'", null);
    }
}
