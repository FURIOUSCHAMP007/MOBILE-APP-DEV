package com.example.petadoptionapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {
    TextView resultTextView;
    PetDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        resultTextView = findViewById(R.id.resultTextView);
        dbHandler = new PetDBHandler(this);

        StringBuilder results = new StringBuilder("Available Pets:\n");
        Cursor availablePets = dbHandler.getAvailablePets();
        while (availablePets.moveToNext()) {
            results.append(availablePets.getString(1)).append("\n");
        }

        results.append("\n1-Year-Old Pets:\n");
        Cursor oneYearPets = dbHandler.getOneYearOldPets();
        while (oneYearPets.moveToNext()) {
            results.append(oneYearPets.getString(1)).append("\n");
        }

        results.append("\nBirds:\n");
        Cursor birds = dbHandler.getBirds();
        while (birds.moveToNext()) {
            results.append(birds.getString(1)).append("\n");
        }

        resultTextView.setText(results.toString());
    }
}
