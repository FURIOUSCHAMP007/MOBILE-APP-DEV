package com.example.petadoptionapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText ownerMail, petAge;
    AutoCompleteTextView categoryInput;
    RadioGroup statusGroup;
    Button saveBtn, showResultsBtn;
    PetDBHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        categoryInput = findViewById(R.id.categoryInput);
        ownerMail = findViewById(R.id.ownerMailInput);
        petAge = findViewById(R.id.petAgeInput);
        statusGroup = findViewById(R.id.statusGroup);
        saveBtn = findViewById(R.id.saveButton);
        showResultsBtn = findViewById(R.id.showResultsButton);

        dbHandler = new PetDBHandler(this);

        // AutoComplete for Pet Categories
        String[] categories = {"Dogs", "Cats", "Birds", "Fishes"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, categories);
        categoryInput.setAdapter(adapter);

        // Save Pet Details
        saveBtn.setOnClickListener(v -> {
            String category = categoryInput.getText().toString();
            String mail = ownerMail.getText().toString();
            String status = ((RadioButton) findViewById(statusGroup.getCheckedRadioButtonId())).getText().toString();
            int age = Integer.parseInt(petAge.getText().toString());

            dbHandler.addPet(category, mail, status, age);
            Toast.makeText(this, "Pet Details Saved!", Toast.LENGTH_SHORT).show();
        });

        // View Results
        showResultsBtn.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ResultActivity.class)));
    }
}
