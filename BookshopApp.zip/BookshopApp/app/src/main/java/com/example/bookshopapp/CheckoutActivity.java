package com.example.bookshopapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class CheckoutActivity extends AppCompatActivity {

    private TextView textViewCustomerDetails, textViewBookDetails;
    private EditText editTextCopies, editTextDeliveryDate;
    private Button buttonCheckout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_checkout);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textViewCustomerDetails = findViewById(R.id.textViewCustomerDetails);
        textViewBookDetails = findViewById(R.id.textViewBookDetails);
        editTextCopies = findViewById(R.id.editTextCopies);
        editTextDeliveryDate = findViewById(R.id.editTextDeliveryDate);
        buttonCheckout = findViewById(R.id.buttonCheckout);

        // Retrieve data from intent
        String book = getIntent().getStringExtra("book");
        String name = getIntent().getStringExtra("name");
        String phone = getIntent().getStringExtra("phone");
        String email = getIntent().getStringExtra("email");
        String address = getIntent().getStringExtra("address");

        // Display customer and book details
        textViewCustomerDetails.setText("Name: " + name + "\nPhone: " + phone + "\nEmail: " + email + "\nAddress: " + address);
        textViewBookDetails.setText("Book: " + book);

        // Set up DatePickerDialog for delivery date
        editTextDeliveryDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(CheckoutActivity.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    editTextDeliveryDate.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                }
            }, year, month, day);
            datePickerDialog.show();
        });

        buttonCheckout.setOnClickListener(v -> {
            int copies = Integer.parseInt(editTextCopies.getText().toString());
            String deliveryDate = editTextDeliveryDate.getText().toString();
            int price = Integer.parseInt(book.split("- INR-")[1]);
            int totalAmount = copies * price;

            // Display total amount and other details
            textViewBookDetails.setText("Book: " + book + "\nCopies: " + copies + "\nDelivery Date: " + deliveryDate + "\nTotal Amount: INR-" + totalAmount);
        });
    }
}