package com.example.garmentcalc;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText Name,Ph,Date,Time;
    Spinner c1,t1;
    Button submit;
    String color_selected,Type_selected,date_str,time_str;
    int date_val,month_val,year_val,minute,hour;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        Name = findViewById(R.id.editTextText);
        Ph = findViewById(R.id.editTextText2);
        Date =  findViewById(R.id.editTextText3);
        Time =  findViewById(R.id.editTextText4);
        c1 = findViewById(R.id.spinner);
        t1 = findViewById(R.id.spinner2);
        submit = findViewById(R.id.button);
        String[] color = {"blue","green","yellow"};
        String[] type = {"pants","shirt","jeans"};
        ArrayAdapter c = new ArrayAdapter(this, android.R.layout.simple_spinner_item,color);
        ArrayAdapter t = new ArrayAdapter(this, android.R.layout.simple_spinner_item,type);
        c.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        t.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        c1.setAdapter(c);
        t1.setAdapter(t);

        c1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                color_selected = adapterView.getSelectedItem().toString();
                System.out.println(color_selected);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });


        t1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Type_selected = adapterView.getSelectedItem().toString();
                System.out.println(Type_selected);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });


        Time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c = Calendar.getInstance();
                int pminute = c.get(Calendar.MINUTE);
                int pHour = c.get(Calendar.HOUR);

                TimePickerDialog t1 = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        minute = i1;
                        hour = i;
                        time_str = String.valueOf(hour)+":"+String.valueOf(minute);
                        Time.setText(time_str);
                        System.out.println(pminute);
                        System.out.println(pHour);
                    }
                },pHour,pminute,true);
                t1.show();
            }
        });

        Date.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Calendar c = Calendar.getInstance();
                int date = c.get(Calendar.DATE);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);
                DatePickerDialog d1 = new DatePickerDialog(MainActivity.this, android.R.style.Theme_DeviceDefault_DialogWhenLarge, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        year_val = i;
                        month_val = i1;
                        date_val = i2;

                        date_str = String.valueOf(year_val)+"/"+String.valueOf(month_val)+"/"+String.valueOf(date_val);
                        Date.setText(date_str);
                    }
                },date,month,year);
                d1.show();
            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity2.class);
                String name = Name.getText().toString();
                String ph = Ph.getText().toString();
                i.putExtra("name",name);
                i.putExtra("ph",ph);
                i.putExtra("date",date_str);
                i.putExtra("Type",Type_selected);
                i.putExtra("color",color_selected);
                i.putExtra("time",time_str);
                startActivity(i);
            }
        });
    }
}