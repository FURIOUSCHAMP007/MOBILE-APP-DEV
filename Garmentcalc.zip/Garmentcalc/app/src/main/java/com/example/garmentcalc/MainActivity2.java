package com.example.garmentcalc;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.garmentcalc.databinding.ActivityMain2Binding;

public class MainActivity2 extends AppCompatActivity {

    TextView t1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        t1 = findViewById(R.id.textView2);
        Intent i = getIntent();
        String name =i.getStringExtra("name");
        String date = i.getStringExtra("date");
        String ph = i.getStringExtra("ph");
        String color = i.getStringExtra("color");
        String Type = i.getStringExtra("Type");
        String Time = i.getStringExtra("time");

        String combined = "name: "+name+" ph: "+ ph + " date : "+ date+" color : "+ color+" type: "+ Type+" Time: "+Time;
        t1.setText(combined);






    }


}