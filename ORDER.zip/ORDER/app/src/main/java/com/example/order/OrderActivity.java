package com.example.order;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class OrderActivity extends AppCompatActivity {
    TextView res;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        res = findViewById(R.id.result);

        // Get the intent and the passed data
        Intent intent = getIntent();
        String cakeFlavour = intent.getStringExtra("ITEM");
        String dated = intent.getStringExtra("DATE");
        String timed = intent.getStringExtra("TIME");

        // Set the result text with the order details
        res.setText("Your Order Placed Successfully.\nYour " + cakeFlavour +
                " cake will be delivered on " + dated + " at " + timed);
    }
}
