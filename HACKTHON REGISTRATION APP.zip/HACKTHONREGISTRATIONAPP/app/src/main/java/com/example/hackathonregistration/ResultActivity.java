package com.example.hackathonregistration;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    TextView resultTextView;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        resultTextView = findViewById(R.id.resultTextView);
        dbHelper = new DBHelper(this);

        Cursor cursor = dbHelper.getStudentsSemesterLessThan5();
        StringBuilder result = new StringBuilder("Students in Semester 5:\n");

        while (cursor.moveToNext()) {
            result.append(cursor.getString(1)).append("\n"); // Name column
        }

        result.append("\nStudents with Java/Python Expertise:\n");
        cursor = dbHelper.getStudentsWithLanguageExpertise();

        while (cursor.moveToNext()) {
            result.append(cursor.getString(1)).append("\n"); // Name column
        }

        resultTextView.setText(result.toString());
    }
}
