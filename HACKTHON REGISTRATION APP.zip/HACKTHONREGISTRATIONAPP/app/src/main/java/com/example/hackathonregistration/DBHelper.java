package com.example.hackathonregistration;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "HackathonDB";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "participants";

    // Table columns
    private static final String ID = "id";
    private static final String NAME = "name";
    private static final String EMAIL = "email";
    private static final String DOB = "dob";
    private static final String CATEGORY = "category";
    private static final String SEMESTER = "semester";
    private static final String LANGUAGE = "language";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NAME + " TEXT, " +
                EMAIL + " TEXT, " +
                DOB + " TEXT, " +
                CATEGORY + " TEXT, " +
                SEMESTER + " INTEGER, " +
                LANGUAGE + " TEXT)";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert a participant
    public void insertParticipant(String name, String email, String dob, String category, int semester, String language) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME, name);
        values.put(EMAIL, email);
        values.put(DOB, dob);
        values.put(CATEGORY, category);
        values.put(SEMESTER, semester);
        values.put(LANGUAGE, language);

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    // Retrieve students with semester < 5
    public Cursor getStudentsSemesterLessThan5() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + SEMESTER + " < 5", null);
    }

    // Retrieve students with expertise in Java or Python
    public Cursor getStudentsWithLanguageExpertise() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + LANGUAGE + " IN ('Java', 'Python')", null);
    }
}
