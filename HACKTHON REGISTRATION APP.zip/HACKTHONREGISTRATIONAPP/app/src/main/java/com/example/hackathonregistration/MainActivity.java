package com.example.hackathonregistration;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText name, email, dob;
    AutoCompleteTextView category;
    Spinner semester;
    RadioGroup languageGroup;
    Button submitBtn;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        dob = findViewById(R.id.dob);
        category = findViewById(R.id.category);
        semester = findViewById(R.id.semester);
        languageGroup = findViewById(R.id.languageGroup);
        submitBtn = findViewById(R.id.submitBtn);

        dbHelper = new DBHelper(this);

        // Setup category AutoComplete
        String[] categories = {"AI", "Blockchain", "Cybersecurity", "Data Analytics"};
        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, categories);
        category.setAdapter(categoryAdapter);

        // Setup semester Spinner
        ArrayAdapter<Integer> semesterAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new Integer[]{1, 2, 3, 4, 5, 6, 7, 8});
        semester.setAdapter(semesterAdapter);

        submitBtn.setOnClickListener(view -> {
            String participantName = name.getText().toString();
            String participantEmail = email.getText().toString();
            String participantDOB = dob.getText().toString();
            String participantCategory = category.getText().toString();
            int participantSemester = Integer.parseInt(semester.getSelectedItem().toString());

            // Get selected programming language
            int selectedLanguageId = languageGroup.getCheckedRadioButtonId();
            RadioButton selectedLanguage = findViewById(selectedLanguageId);
            String languageExpertise = selectedLanguage.getText().toString();

            dbHelper.insertParticipant(participantName, participantEmail, participantDOB, participantCategory, participantSemester, languageExpertise);

            // Navigate to ResultActivity
            Intent intent = new Intent(MainActivity.this, ResultActivity.class);
            startActivity(intent);
        });
    }
}