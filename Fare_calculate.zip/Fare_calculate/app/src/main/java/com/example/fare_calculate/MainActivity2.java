package com.example.fare_calculate;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.fare_calculate.databinding.ActivityMain2Binding;

public class MainActivity2 extends AppCompatActivity {


    EditText Kids,Elders;
    Button submit;
    int no_peopl;
    int Age;
    TextView t1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Kids = findViewById(R.id.editTextText7);
        Elders = findViewById(R.id.editTextText8);
        submit = findViewById(R.id.button2);
        t1 = findViewById(R.id.textView);
        Intent i = getIntent();

        String name = i.getStringExtra("name");
        String Date = i.getStringExtra("date");
         Age = Integer.parseInt(i.getStringExtra("age"));
        String Time_val = i.getStringExtra("time_val");
         no_peopl = Integer.parseInt(i.getStringExtra("nopeople"));

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int kids_val = Integer.parseInt(Kids.getText().toString());
                int elders_val = Integer.parseInt(Elders.getText().toString());
//                System.out.println(Age);
//                System.out.println(name);
//                System.out.println(Date);
//                System.out.println(Time_val);
//                System.out.println(no_peopl);
//                System.out.println(kids_val);
//                System.out.println(elders_val);
                no_peopl = no_peopl-kids_val;
                no_peopl = no_peopl-elders_val;
                kids_val = (100*kids_val)/100;
                kids_val = kids_val*50;
                elders_val = (100*elders_val)/100;
                elders_val = elders_val*25;
                no_peopl = no_peopl*100;

                int total = no_peopl+kids_val+elders_val;

                System.out.println(total);
                t1.setText("your Total will be: "+ total);

            }
        });

    }


}