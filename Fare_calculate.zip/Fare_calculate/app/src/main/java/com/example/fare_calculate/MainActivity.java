package com.example.fare_calculate;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText Name,Age,Date,noPeople;
    Button submit;
    Spinner s1;
    int year,month,day;
    String[] time = {"morning","evening","Night"};
    String time_val;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        Name = findViewById(R.id.editTextText);
        Date = findViewById(R.id.editTextText2);
        Age = findViewById(R.id.editTextText3);
        noPeople = findViewById(R.id.editTextText4);
        s1 = findViewById(R.id.spinner);
        submit = findViewById(R.id.button);

        Date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog d1 = new DatePickerDialog(MainActivity.this);
                d1.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                       day = i2;
                       month = i1;
                       year = i;
                       String date = day +" "+month+" "+year;
                       Date.setText(date);
                    }
                });
                d1.show();
            }
        });

        ArrayAdapter a1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item,time);
        a1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        s1.setAdapter(a1);
        s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                time_val = adapterView.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = Name.getText().toString();
                String age = Age.getText().toString();
                String date = day +" "+month+" "+year;
                String noofpeople = noPeople.getText().toString();
                Intent i = new Intent(getApplicationContext(), MainActivity2.class);

                System.out.println(date);
                i.putExtra("name",name);
                i.putExtra("age",age);
                i.putExtra("date",date);
                i.putExtra("time_val",time_val);
                i.putExtra("nopeople",noofpeople);
                startActivity(i);


            }
        });






    }
}