package com.example.dbproject;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHandler extends SQLiteOpenHelper {

    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE students (stuId VARCHAR(10), stuname VARCHAR(20))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public void insertRecord(String sid, String sname) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO students VALUES (?, ?)", new String[]{sid, sname});
        db.close();
    }

    public void deleteRecord(String sid) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("students", "stuId=?", new String[]{sid});
        db.close();
    }

    public String displayRecord() {
        StringBuilder tableData = new StringBuilder();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM students", null);

        while (cursor.moveToNext()) {
            tableData.append(cursor.getString(0)).append(":").append(cursor.getString(1)).append("\n");
        }
        db.close();
        return tableData.toString();
    }
}
