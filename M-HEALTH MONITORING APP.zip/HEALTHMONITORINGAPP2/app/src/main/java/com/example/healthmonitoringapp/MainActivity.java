package com.example.healthmonitoringapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText bpBox, tempBox;
    private Button submitBtn;

    private static final String CHANNEL_ID = "health_monitor_channel";
    private static final int NOTIFICATION_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bpBox = findViewById(R.id.bpBox);
        tempBox = findViewById(R.id.tempBox);
        submitBtn = findViewById(R.id.submitBtn);

        createNotificationChannel();

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String bpInput = bpBox.getText().toString();
                String tempInput = tempBox.getText().toString();

                if (!bpInput.isEmpty() && !tempInput.isEmpty()) {
                    int bp = Integer.parseInt(bpInput);
                    int temp = Integer.parseInt(tempInput);

                    String message;
                    if ((bp >= 60 && bp <= 100) && temp == 98) {
                        message = "Your vitals are fine.";
                    } else {
                        message = "You need to consult a doctor.";
                    }

                    showNotification(bp, temp, message);

                    Intent intent = new Intent(MainActivity.this, NotificationResult.class);
                    intent.putExtra("Message", message);
                    startActivity(intent);
                }
            }
        });
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Health Monitor Notifications";
            String description = "Channel for health monitoring notifications";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void showNotification(int bp, int temp, String message) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Health Status")
                .setContentText("BP: " + bp + " Temp: " + temp + " - " + message)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }
}
