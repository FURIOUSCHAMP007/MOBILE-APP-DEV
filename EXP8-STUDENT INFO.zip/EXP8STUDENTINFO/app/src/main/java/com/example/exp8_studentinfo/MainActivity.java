package com.example.exp8_studentinfo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    ListView list;
    // Array of student names
    String students[] = {"ABC", "DEF", "GHI", "JKL"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find ListView from layout
        list = findViewById(R.id.studentList);

        // Set up ArrayAdapter to display the list of student names
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, students);
        list.setAdapter(adapter);

        // Handle click events on the ListView items
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the fragment instance by its ID
                DetailsFragment frag = (DetailsFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentPortion);

                // Call the change method in the fragment to update the student's details
                frag.change(position);
            }
        });
    }
}
