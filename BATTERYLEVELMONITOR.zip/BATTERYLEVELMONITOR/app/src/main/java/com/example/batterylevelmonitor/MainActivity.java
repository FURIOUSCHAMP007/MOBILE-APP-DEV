
package com.example.batterylevelmonitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView batteryLevelText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        batteryLevelText = findViewById(R.id.batteryLevelText);

        // Register the BroadcastReceiver to listen for battery level changes
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryLevelReceiver, filter);
    }

    // Create a BroadcastReceiver to monitor the battery level
    private final BroadcastReceiver batteryLevelReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Get the current battery level
            int level = intent.getIntExtra("level", 0);
            int scale = intent.getIntExtra("scale", 100);

            // Calculate the percentage
            int batteryPercentage = (int) ((level / (float) scale) * 100);

            // Update the UI with the current battery level
            batteryLevelText.setText("Battery Level: " + batteryPercentage + "%");
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the receiver when the activity is destroyed to avoid memory leaks
        unregisterReceiver(batteryLevelReceiver);
    }
}
