package com.example.samplepaper;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    Button b1;
    SqlDataBase sql = new SqlDataBase(this,"data",null,1);
    EditText name,phno;
    Spinner items;
    TextView DateBox,Time;
    RadioButton r1;
    RadioGroup rg;
    AutoCompleteTextView noitems;
    String[] itemsArray = {"chocolate","Burger","pizza","dosa"};
    String[] noItemsaray = {"1","2","3","4"};
    String dateVal,timeVal;
    String Selecteditem = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);




        b1 = findViewById(R.id.button);
        name = findViewById(R.id.editTextText);
        phno = findViewById(R.id.editTextText2);
        items = findViewById(R.id.spinner);
        DateBox = findViewById(R.id.editTextText3);
        Time = findViewById(R.id.editTextText4);
        noitems = findViewById(R.id.autoCompleteTextView);
        rg = findViewById(R.id.radioGroup);
        ArrayAdapter a1 = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,itemsArray);
        items.setAdapter(a1);

        items.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Selecteditem = items.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        DateBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int date = c.get(Calendar.DATE);
                int Month = c.get(Calendar.MONTH);

                DatePickerDialog d1 = new DatePickerDialog(MainActivity.this, android.R.style.Theme_DeviceDefault_DialogWhenLarge, new DatePickerDialog.OnDateSetListener() {
                    @Override
                  public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        dateVal = i+"/"+i1+"/"+i2;
                        DateBox.setText(dateVal);
                   }
                },year,Month,date);
                d1.show();
            }
        });

        Time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c = Calendar.getInstance();
                int hour = c.get(Calendar.HOUR);
                int minute = c.get(Calendar.MINUTE);
                TimePickerDialog t1 = new TimePickerDialog(MainActivity.this, android.R.style.Theme_DeviceDefault_DialogWhenLarge, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        timeVal = i+":"+i1;
                        Time.setText(timeVal);
                    }
                },minute,hour,true);
                t1.show();

            }
        });
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                r1 = findViewById(i);
            }
        });



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Name = name.getText().toString();
                String phn = phno.getText().toString();
                String noItems = noitems.getText().toString();
                Log.d("test", phn+noItems+Name+" "+dateVal+ " "+ timeVal);
                String gender = r1.getText().toString();
                System.out.println("clicked");
                sql.insert(Name,Selecteditem,noItems,dateVal,timeVal,gender);
                String tdata = sql.Display();
                Intent i = new Intent(getApplicationContext(), Result.class);
                i.putExtra("tdata",tdata);
                i.putExtra("count",String.valueOf(sql.GetCount()));

                startActivity(i);
            }
        });



        ArrayAdapter a2 = new ArrayAdapter(this, android.R.layout.select_dialog_item,noItemsaray);
        noitems.setAdapter(a2);
        noitems.setThreshold(1);







    }
}