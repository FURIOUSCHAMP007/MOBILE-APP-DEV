package com.example.samplepaper;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SqlDataBase extends SQLiteOpenHelper {

    public SqlDataBase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }




    @Override
    public void onCreate(SQLiteDatabase db) {
    db.execSQL("create table customer(name varchar(20),items varchar(20) , NOI varchar(20),Date varchar(20) , TOS varchar(20) , Gender varchar(20));");
    }

    public void insert(String name,String items,String NOI,String Date,String TOS,String Gender){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("insert into customer values(?,?,?,?,?,?)",new String[]{name,items,NOI,Date,TOS,Gender});
    }

    public String Display(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from customer",null);
        String tdata = "";
        while(c.moveToNext()){
            String a = c.getString(0);
            String b = c.getString(1);
            String d = c.getString(2);
            String e = c.getString(3);
            String f = c.getString(4);
            String g = c.getString(5);
            System.out.println(" "+a+" "+b+" "+" "+d+" "+e+" "+f);

            tdata = tdata+" "+a+" "+b+" "+d+" "+e+" "+f+" "+g +" \n";
        }
        c.close();
        System.out.println("from db"+tdata);
        return  tdata;
    }

    public int GetCount(){
        SQLiteDatabase db = this.getReadableDatabase();
        int number =0;
        Cursor c = db.rawQuery("select count(*) from customer",null);
        while(c.moveToNext()){
            number = Integer.parseInt(c.getString(0));
        }
        return number;

    }



    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
