package com.example.weddingplanner;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private EditText brideNameInput, groomNameInput;
    private Spinner eventSpinner;
    private DatePicker weddingDatePicker;
    private Button proceedButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        brideNameInput = findViewById(R.id.editTextBrideName);
        groomNameInput = findViewById(R.id.editTextGroomName);
        eventSpinner = findViewById(R.id.eventSpinner);
        weddingDatePicker = findViewById(R.id.datePickerWedding);
        proceedButton = findViewById(R.id.btnProceed);

        // Spinner setup (Example event types)
        String[] events = {"Mehndi", "Sangeeth", "Reception", "Wedding"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, events);
        eventSpinner.setAdapter(adapter);

        // Button click listener
        proceedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get values from input fields
                String brideName = brideNameInput.getText().toString();
                String groomName = groomNameInput.getText().toString();
                String eventType = eventSpinner.getSelectedItem().toString();

                // Get the selected wedding date
                int day = weddingDatePicker.getDayOfMonth();
                int month = weddingDatePicker.getMonth();
                int year = weddingDatePicker.getYear();

                // Store the details in a HashMap
                HashMap<String, String> weddingDetails = new HashMap<>();
                weddingDetails.put("brideName", brideName);
                weddingDetails.put("groomName", groomName);
                weddingDetails.put("eventType", eventType);
                weddingDetails.put("weddingDate", day + "/" + (month + 1) + "/" + year);

                // Pass the details to the next activity
                Intent intent = new Intent(MainActivity.this, SummaryActivity.class);
                intent.putExtra("weddingDetails", weddingDetails);
                intent.putExtra("day", day);
                intent.putExtra("month", month);
                intent.putExtra("year", year);
                startActivity(intent);
            }
        });
    }
}

