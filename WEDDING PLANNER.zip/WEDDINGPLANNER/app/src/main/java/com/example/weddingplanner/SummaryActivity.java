package com.example.weddingplanner;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.HashMap;

public class SummaryActivity extends AppCompatActivity {

    private TextView summaryTextView, daysLeftTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        // Initialize TextViews
        summaryTextView = findViewById(R.id.summaryTextView);
        daysLeftTextView = findViewById(R.id.daysLeftTextView);

        // Get the wedding details from the intent
        HashMap<String, String> weddingDetails = (HashMap<String, String>) getIntent().getSerializableExtra("weddingDetails");

        // Get the wedding date from the intent
        int day = getIntent().getIntExtra("day", 0);
        int month = getIntent().getIntExtra("month", 0);
        int year = getIntent().getIntExtra("year", 0);

        // Display the wedding details
        String summary = "Bride: " + weddingDetails.get("brideName") + "\n"
                + "Groom: " + weddingDetails.get("groomName") + "\n"
                + "Event: " + weddingDetails.get("eventType") + "\n"
                + "Wedding Date: " + weddingDetails.get("weddingDate");
        summaryTextView.setText(summary);

        // Calculate the number of days left until the wedding
        Calendar weddingDate = Calendar.getInstance();
        weddingDate.set(year, month, day);

        Calendar currentDate = Calendar.getInstance();
        long timeDifference = weddingDate.getTimeInMillis() - currentDate.getTimeInMillis();
        long daysLeft = timeDifference / (1000 * 60 * 60 * 24);

        // Display the number of days left
        daysLeftTextView.setText("Days Left: " + daysLeft);
    }
}
