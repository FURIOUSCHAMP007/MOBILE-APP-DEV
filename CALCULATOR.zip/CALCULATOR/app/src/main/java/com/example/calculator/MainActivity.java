package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNumber1, editTextNumber2;
    private TextView textViewResult;
    private Button buttonAdd, buttonSubtract, buttonMultiply, buttonDivide, buttonResult;

    private double value1, value2, result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Setup edge-to-edge insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views
        editTextNumber1 = findViewById(R.id.editTextNumber1);
        editTextNumber2 = findViewById(R.id.editTextNumber2);
        textViewResult = findViewById(R.id.textViewResult);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonSubtract = findViewById(R.id.buttonSubtract);
        buttonMultiply = findViewById(R.id.buttonMultiply);
        buttonDivide = findViewById(R.id.buttonDivide);
        buttonResult = findViewById(R.id.buttonResult);

        // Setup click listeners for the operation buttons
        buttonAdd.setOnClickListener(view -> performOperation('+'));
        buttonSubtract.setOnClickListener(view -> performOperation('-'));
        buttonMultiply.setOnClickListener(view -> performOperation('*'));
        buttonDivide.setOnClickListener(view -> performOperation('/'));

        // Display the result when the Result button is clicked
        buttonResult.setOnClickListener(view -> textViewResult.setText(String.valueOf(result)));
    }

    private void performOperation(char operator) {
        // Get the values from input fields
        if (getValues()) {
            switch (operator) {
                case '+':
                    result = value1 + value2;
                    break;
                case '-':
                    result = value1 - value2;
                    break;
                case '*':
                    result = value1 * value2;
                    break;
                case '/':
                    if (value2 != 0) {
                        result = value1 / value2;
                    } else {
                        showToast("Cannot divide by zero");
                        result = 0;
                    }
                    break;
            }
        }
    }

    private boolean getValues() {
        String num1 = editTextNumber1.getText().toString();
        String num2 = editTextNumber2.getText().toString();

        if (num1.isEmpty() || num2.isEmpty()) {
            showToast("Please enter both numbers");
            return false;
        }

        try {
            value1 = Double.parseDouble(num1);
            value2 = Double.parseDouble(num2);
        } catch (NumberFormatException e) {
            showToast("Invalid number format");
            return false;
        }
        return true;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
