package com.example.tripplanner;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class SummaryActivity extends AppCompatActivity {

    TextView summaryTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        summaryTextView = findViewById(R.id.summaryTextView);

        Intent intent = getIntent();
        String destination = intent.getStringExtra("destination");
        String travelClass = intent.getStringExtra("travelClass");
        long travelDateMillis = intent.getLongExtra("travelDate", -1);

        // Calculate the number of days remaining
        long currentTimeMillis = Calendar.getInstance().getTimeInMillis();
        long diffInMillis = travelDateMillis - currentTimeMillis;
        long daysRemaining = TimeUnit.MILLISECONDS.toDays(diffInMillis);

        String summary = "Destination: " + destination + "\n" +
                "Travel Class: " + travelClass + "\n" +
                "Days Remaining: " + daysRemaining;

        summaryTextView.setText(summary);
    }
}
