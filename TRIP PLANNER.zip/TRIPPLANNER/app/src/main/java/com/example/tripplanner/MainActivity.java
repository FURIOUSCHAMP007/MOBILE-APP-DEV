package com.example.tripplanner;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText destinationInput;
    TextView dateTextView;
    Button dateButton, submitButton;
    Spinner classSpinner;
    Calendar selectedDate;
    String selectedClass = "Economy";  // Default value

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        destinationInput = findViewById(R.id.destinationInput);
        dateTextView = findViewById(R.id.dateTextView);
        dateButton = findViewById(R.id.dateButton);
        submitButton = findViewById(R.id.submitButton);
        classSpinner = findViewById(R.id.classSpinner);

        // Spinner setup
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.travel_classes, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        classSpinner.setAdapter(adapter);
        classSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedClass = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedClass = "Economy"; // Default value
            }
        });

        // DatePicker setup
        selectedDate = Calendar.getInstance();
        dateButton.setOnClickListener(v -> {
            DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                    (view, year, month, dayOfMonth) -> {
                        selectedDate.set(year, month, dayOfMonth);
                        dateTextView.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                    },
                    selectedDate.get(Calendar.YEAR),
                    selectedDate.get(Calendar.MONTH),
                    selectedDate.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        });

        // Submit button action
        submitButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SummaryActivity.class);
            intent.putExtra("destination", destinationInput.getText().toString());
            intent.putExtra("travelClass", selectedClass);
            intent.putExtra("travelDate", selectedDate.getTimeInMillis());
            startActivity(intent);
        });
    }
}
