package com.example.calorie_tracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button b1;
    EditText Calorie,Mealtype;
    RadioButton rb;
    String MealTime;
    String calorie;
    String MealTypeval;
    RadioGroup r1;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.button);
        Calorie = findViewById(R.id.editTextText);
        Mealtype = findViewById(R.id.editTextText2);

        r1 = findViewById(R.id.radioGroup);
       r1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
           @Override
           public void onCheckedChanged(RadioGroup radioGroup, int i) {
               rb = findViewById(i);
           }
       });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                calorie = Calorie.getText().toString();
                MealTypeval = Mealtype.getText().toString();
                MealTime = rb.getText().toString();

                System.out.println(calorie);
                System.out.println(MealTime);
                System.out.println(MealTypeval);
                Intent i = new Intent(getApplicationContext(),MainActivity2.class);
                i.putExtra("calorie",calorie);
                i.putExtra("MealType",MealTypeval);
                i.putExtra("MealTime",MealTime);
                startActivity(i);

            }



        });

    }
}