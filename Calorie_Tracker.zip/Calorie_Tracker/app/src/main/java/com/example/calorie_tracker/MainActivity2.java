package com.example.calorie_tracker;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.calorie_tracker.databinding.ActivityMain2Binding;

public class MainActivity2 extends AppCompatActivity {


    TextView Result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Result = findViewById(R.id.textView3);
        Intent i = getIntent();
        String Calorie = i.getStringExtra("calorie");
        String MealType = i.getStringExtra("MealType");
        String MealTime = i.getStringExtra("MealTime");
        String text = "Calorie : " + Calorie + " MealType : " +MealType+" MealTime : "+ MealTime;
        System.out.println(text);
        Result.setText(text);






    }


}