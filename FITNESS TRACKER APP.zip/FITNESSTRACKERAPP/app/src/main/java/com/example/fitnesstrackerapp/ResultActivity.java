package com.example.fitnesstrackerapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    SQLiteHelper db;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        db = new SQLiteHelper(this);
        resultText = findViewById(R.id.resultText);

        Cursor maxCalories = db.getMaxCaloriesExercise();
        Cursor userCount = db.getUserCount();

        if (maxCalories.moveToFirst()) {
            int exerciseIndex = maxCalories.getColumnIndex("exercise");
            if (exerciseIndex != -1) {
                String exercise = maxCalories.getString(exerciseIndex);
                resultText.setText("Exercise with Max Calories: " + exercise);
            }
        }

        if (userCount.moveToFirst()) {
            int count = userCount.getInt(0);
            resultText.append("\nTotal Users: " + count);
        }
    }
}