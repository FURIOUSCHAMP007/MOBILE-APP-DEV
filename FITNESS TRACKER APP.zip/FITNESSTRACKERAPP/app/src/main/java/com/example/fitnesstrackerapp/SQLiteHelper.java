package com.example.fitnesstrackerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "fitnessDB.db";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "exercise_details";

    // Columns
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_EXERCISE = "exercise";
    private static final String COLUMN_DURATION = "duration";
    private static final String COLUMN_CALORIES = "calories";
    private static final String COLUMN_DATE = "date";

    public SQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_EXERCISE + " TEXT, " +
                COLUMN_DURATION + " TEXT, " +
                COLUMN_CALORIES + " INTEGER, " +
                COLUMN_DATE + " TEXT);";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void insertData(String name, String exercise, String duration, int calories, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_EXERCISE, exercise);
        values.put(COLUMN_DURATION, duration);
        values.put(COLUMN_CALORIES, calories);
        values.put(COLUMN_DATE, date);
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public Cursor getMaxCaloriesExercise() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " ORDER BY " + COLUMN_CALORIES + " DESC LIMIT 1;";
        return db.rawQuery(query, null);
    }

    public Cursor getUserCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT COUNT(DISTINCT " + COLUMN_NAME + ") AS user_count FROM " + TABLE_NAME + ";";
        return db.rawQuery(query, null);
    }
}
