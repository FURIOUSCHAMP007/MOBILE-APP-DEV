package com.example.fitnesstrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    SQLiteHelper db;
    EditText nameInput;
    AutoCompleteTextView exerciseInput;
    Spinner durationSpinner;
    RadioGroup caloriesRadioGroup;
    Button saveButton, resultButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new SQLiteHelper(this);

        nameInput = findViewById(R.id.nameInput);
        exerciseInput = findViewById(R.id.exerciseInput);
        durationSpinner = findViewById(R.id.durationSpinner);
        caloriesRadioGroup = findViewById(R.id.caloriesRadioGroup);
        saveButton = findViewById(R.id.saveButton);
        resultButton = findViewById(R.id.resultButton);

        // AutoComplete for Exercise Types
        String[] exercises = {"Cardio", "Strength Training", "Yoga"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, exercises);
        exerciseInput.setAdapter(adapter);

        // Spinner for Duration
        String[] durations = {"30 Minutes", "1 Hour", "2 Hours"};
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, durations);
        durationSpinner.setAdapter(spinnerAdapter);

        saveButton.setOnClickListener(view -> {
            String name = nameInput.getText().toString();
            String exercise = exerciseInput.getText().toString();
            String duration = durationSpinner.getSelectedItem().toString();
            int calories = getSelectedCalories();
            String date = "2024-09-01";

            db.insertData(name, exercise, duration, calories, date);
        });

        resultButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ResultActivity.class);
            startActivity(intent);
        });
    }

    private int getSelectedCalories() {
        int selectedId = caloriesRadioGroup.getCheckedRadioButtonId();
        if (selectedId == R.id.cal1) return 1000;
        else if (selectedId == R.id.cal2) return 2000;
        else return 3000;
    }
}
