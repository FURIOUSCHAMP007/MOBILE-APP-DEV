package com.example.animationsexample;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView im;
    Button bli, fad, mov, rot, sli, zoom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        im = findViewById(R.id.logoImage);
        bli = findViewById(R.id.blinkBtn);
        rot = findViewById(R.id.rotBtn);
        fad = findViewById(R.id.fadeBtn);
        mov = findViewById(R.id.moveBtn);
        sli = findViewById(R.id.slideBtn);
        zoom = findViewById(R.id.zoomBtn);

        bli.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink);
            im.startAnimation(animation);
        });

        rot.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.rotate);
            im.startAnimation(animation);
        });

        fad.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade);
            im.startAnimation(animation);
        });

        mov.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.move);
            im.startAnimation(animation);
        });

        sli.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide);
            im.startAnimation(animation);
        });

        zoom.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom);
            im.startAnimation(animation);
        });
    }
}
